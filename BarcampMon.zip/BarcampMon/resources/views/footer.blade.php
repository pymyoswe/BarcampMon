<footer  class="navbar navbar-fixed-bottom" id="footer">

        <div class="text-center">
            <p>&copy; Copyright Barcamp Mon. All rights reserved.</p>
            <p>Developed by <strong style="color: #ffffff">New Tech Group</strong></p>

        </div>


</footer> <!--/#footer-->





