<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TopicBoard extends Model
{
    //
}
