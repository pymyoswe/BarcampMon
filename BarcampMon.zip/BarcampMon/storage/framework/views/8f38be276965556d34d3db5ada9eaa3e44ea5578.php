;
<?php $__env->startSection('content'); ?>
    <section id="blog">
        <div class="container">
            <div class="row text-center clearfix">
                <div class="col-sm-8 col-sm-offset-2">
                    <h2 class="title-one">Topic Board</h2>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $topic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-4">
                        <div class="single-blog">
                            <img src="<?php echo e(route('welcomeTopic',['photoName'=>$t->photo])); ?>" alt="" />
                            <h2><?php echo e($t->title); ?></h2>
                            <ul class="post-meta">
                                <li><i class="fa fa-pencil-square-o"></i><strong> Speaker :</strong> <?php echo e($t->speaker); ?></li>
                            </ul>
                            <a href="" class="btn btn-primary" data-toggle="modal" data-target="#<?php echo e($t->id); ?>">View</a>
                        </div>
                        <div class="modal fade" id="<?php echo e($t->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-body">
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                        <img src="<?php echo e(route('welcomeTopic',['photoName'=>$t->photo])); ?>" alt="" />
                                        <h2><?php echo e($t->title); ?></h2>
                                        <p><?php echo e($t->status); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section> <!--/#blog-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>