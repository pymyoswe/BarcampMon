;
<?php $__env->startSection('content'); ?>
    <section id="gallery">
        <div class="container">
            <div class="row text-center">
                <div class="col-sm-8 col-sm-offset-2">
                    <h2 class="title-one">Gallery</h2>
                    <p></p>
                </div>
            </div>


            <div class="portfolio-items">
            <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-3 col-xs-12 portfolio-item">
                    <div class="view efffect" >
                        <div class="portfolio-image">
                            <img  src="<?php echo e(route('welcomeGallery',['photoName'=>$g->photo])); ?>" alt="">
                        </div>
                        <div class="mask text-center">
                            <h3 class="photoTitle"><?php echo e($g->title); ?></h3>
                            <h4 class="photoStatus"><?php echo e($g->status); ?></h4>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>

    </section> <!--/#gallery-->


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>