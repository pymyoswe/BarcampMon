<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>BarCamp Mon Dashboard</title>

    <!-- Styles -->
    <link href="<?php echo e(asset('fontAwesome/css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bootstrap/css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bootstrap/css/bootstrap.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('Templatedemo/prettyPhoto.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('Templatedemo/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('Templatedemo/main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('Templatedemo/responsive.css')); ?>" rel="stylesheet">

</head>

<body>

    <?php echo $__env->make('dashboardNavbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script src="<?php echo e(asset('bootstrap/js/app.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('bootstrap/js/jquery.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('bootstrap/js/bootstrap.js')); ?>" type="text/javascript"></script>

<script  src="<?php echo e(asset('Templatedemo/smoothscroll.js')); ?>" type="text/javascript"></script>
<script  src="<?php echo e(asset('Templatedemo/jquery.isotope.min.js')); ?>" type="text/javascript"></script>
<script  src="<?php echo e(asset('Templatedemo/jquery.prettyPhoto.js')); ?>" type="text/javascript"></script>
<script  src="<?php echo e(asset('Templatedemo/jquery.parallax.js')); ?>" type="text/javascript"></script>
<script  src="<?php echo e(asset('Templatedemo/main.js')); ?>" type="text/javascript"></script>



</body>

</html>