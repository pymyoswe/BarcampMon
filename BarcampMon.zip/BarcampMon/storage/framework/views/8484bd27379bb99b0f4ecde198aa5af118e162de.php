<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>BarCamp Mon</title>

    <!-- Styles -->
    <link href="<?php echo e(asset('fontAwesome/css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bootstrap/css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bootstrap/css/bootstrap.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('Templatedemo/prettyPhoto.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('Templatedemo/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('Templatedemo/main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('Templatedemo/responsive.css')); ?>" rel="stylesheet">


    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>;
    </script>
</head>
<body>
        <div id="app">
            <?php echo $__env->make('navBar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>


        <script src="<?php echo e(asset('bootstrap/js/app.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('bootstrap/js/jquery.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('bootstrap/js/bootstrap.js')); ?>" type="text/javascript"></script>

        <script  src="<?php echo e(asset('Templatedemo/smoothscroll.js')); ?>" type="text/javascript"></script>
        <script  src="<?php echo e(asset('Templatedemo/jquery.isotope.min.js')); ?>" type="text/javascript"></script>
        <script  src="<?php echo e(asset('Templatedemo/jquery.prettyPhoto.js')); ?>" type="text/javascript"></script>
        <script  src="<?php echo e(asset('Templatedemo/jquery.parallax.js')); ?>" type="text/javascript"></script>
        <script  src="<?php echo e(asset('Templatedemo/main.js')); ?>" type="text/javascript"></script>




</body>
</html>
