<?php $__env->startSection('content'); ?>
    <section id="contact">
        <div class="container">
            <div class="row text-center clearfix">
                <div class="col-sm-8 col-sm-offset-2">
                    <div class="contact-heading">
                        <h2 class="title-one">Contact With Us</h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="contact-details">
                <div class="pattern"></div>
                <div class="row text-center clearfix">
                    <div class="col-sm-6">
                        <div class="contact-address">
                            <address>
                                <p><span>Organizer's Contact </span> Info</p><strong>Email:barcampmon@gmail.com
                                    <br>Thaton Township<br>Mon State, Myanmar</strong><br>
                            </address>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div id="contact-form-section">
                            <?php if(Session::has('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(Session::get('success')); ?>

                                </div>
                            <?php endif; ?>
                                <form id="contact-form" class="contact" name="contact-form" method="post" action="<?php echo e(route('sendEmail')); ?>">
                                    <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                                        <input type="text" name="name" class="form-control name-field" required="required" placeholder="Your Name">
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                                        <input type="email" name="email" class="form-control mail-field" required="required" placeholder="Your Email">
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('message') ? 'has-error' : ''); ?>">
                                        <textarea name="message" id="message" required="required" class="form-control" rows="8" placeholder="Message"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary">Send</button>
                                    </div>
                                    <?php echo e(csrf_field()); ?>

                                </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container" style="margin-top: 30px">
            <div class="row">
                <div class="col-sm-12">
                    <div id="map" style="width:100%;height:500px"></div>

                    <script>
                        function myMap() {
                            var mapCanvas = document.getElementById("map");
                            var myCenter = new google.maps.LatLng(16.8889041,97.386243);
                            var mapOptions = {center: myCenter, zoom: 13};
                            var map = new google.maps.Map(mapCanvas,mapOptions);
                            var marker = new google.maps.Marker({
                                position: myCenter,
                                animation: google.maps.Animation.BOUNCE
                            });
                            marker.setMap(map);
                        }
                    </script>

                    <script src="https://maps.googleapis.com/maps/api/js?&callback=myMap"></script>


                </div>
            </div>
        </div>
    </section> <!--/#contact-->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>