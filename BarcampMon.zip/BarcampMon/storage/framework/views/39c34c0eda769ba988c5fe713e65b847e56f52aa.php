;
<?php $__env->startSection('content'); ?>
    <section id="portfolio">
        <div class="container">
            <div class="row text-center">
                <div class="col-sm-8 col-sm-offset-2">
                    <h2 class="title-one">Gallery</h2>
                    <p></p>
                </div>
            </div>
            <!--<ul class="portfolio-filter text-center">
                <li><a class="btn btn-default active" href="#" data-filter="*">2017</a></li>
                <li><a class="btn btn-default" href="#" data-filter=".html">Html</a></li>
                <li><a class="btn btn-default" href="#" data-filter=".wordpress">Wordpress</a></li>
                <li><a class="btn btn-default" href="#" data-filter=".joomla">Joomla</a></li>
                <li><a class="btn btn-default" href="#" data-filter=".megento">Megento</a></li>
            </ul>--><!--/#portfolio-filter-->

            <div class="portfolio-items">
                <div class="col-sm-3 col-xs-12 portfolio-item html">
                    <div class="view efffect">
                        <div class="portfolio-image">
                            <img src="Templatedemo/1.jpg" alt=""></div>
                        <div class="mask text-center">
                            <h3>Novel</h3>
                            <h4>Lorem ipsum dolor sit amet consectetur</h4>
                            <a href="#"><i class="fa fa-link"></i></a>
                            <a href="" data-gallery="prettyPhoto"><i class="fa fa-search-plus"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-12 portfolio-item jooma">
                    <div class="view efffect" >
                        <div class="portfolio-image">
                            <img src="Templatedemo/2.jpg" alt="">
                        </div>
                        <div class="mask text-center">
                            <h3>Novel</h3>
                            <h4>Lorem ipsum dolor sit amet consectetur</h4>
                            <a href="#"><i class="fa fa-link"></i></a>
                            <a href="Templatedemo/big-item4.jpg" data-gallery="prettyPhoto"><i class="fa fa-search-plus"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-12 portfolio-item wordpress">
                    <div class="view efffect">
                        <div class="portfolio-image">
                            <img src="Templatedemo/3.jpg" alt="">
                        </div>
                        <div class="mask text-center">
                            <h3>Novel</h3>
                            <h4>Lorem ipsum dolor sit amet consectetur</h4>
                            <a href="#"><i class="fa fa-link"></i></a>
                            <a href="Templatedemo/big-item.jpg" data-gallery="prettyPhoto"><i class="fa fa-search-plus"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-12 portfolio-item megento">
                    <div class="view efffect">
                        <div class="portfolio-image">
                            <img src="Templatedemo/4.jpg" alt="">
                        </div>
                        <div class="mask text-center">
                            <h3>Novel</h3>
                            <h4>Lorem ipsum dolor sit amet consectetur</h4>
                            <a href="#"><i class="fa fa-link"></i></a>
                            <a href="Templatedemo/big-item.jpg" data-gallery="prettyPhoto"><i class="fa fa-search-plus"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-12 portfolio-item html">
                    <div class="view efffect">
                        <div class="portfolio-image">
                            <img src="Templatedemo/2.jpg" alt="">
                        </div> <div class="mask text-center">
                            <h3>Novel</h3>
                            <h4>Lorem ipsum dolor sit amet consectetur</h4>
                            <a href="#"><i class="fa fa-link"></i></a>
                            <a href="Templatedemo/big-item.jpg" data-gallery="prettyPhoto"><i class="fa fa-search-plus"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-12 portfolio-item wordpress">
                    <div class="view efffect">
                        <div class="portfolio-image">
                            <img src="Templatedemo/1.jpg" alt="">
                        </div>
                        <div class="mask text-center">
                            <h3>Novel</h3>
                            <h4>Lorem ipsum dolor sit amet consectetur</h4>
                            <a href="#"><i class="fa fa-link"></i></a>
                            <a href="Templatedemo/big-item.jpg" data-gallery="prettyPhoto"><i class="fa fa-search-plus"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-12 portfolio-item html">
                    <div class="view efffect">
                        <div class="portfolio-image">
                            <img src="Templatedemo/4.jpg" alt="">
                        </div>
                        <div class="mask text-center">
                            <h3>Novel</h3>
                            <h4>Lorem ipsum dolor sit amet consectetur</h4>
                            <a href="#"><i class="fa fa-link"></i></a>
                            <a href="Templatedemo/big-item.jpg" data-gallery="prettyPhoto"><i class="fa fa-search-plus"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-12 portfolio-item joomla">
                    <div class="view efffect">
                        <div class="portfolio-image">
                            <img src="Templatedemo/3.jpg" alt=""></div>
                        <div class="mask text-center">
                            <h3>Novel</h3>
                            <h4>Lorem ipsum dolor sit amet consectetur</h4>
                            <a href="#"><i class="fa fa-link"></i></a>
                            <a href="Templatedemo/big-item.jpg" data-gallery="prettyPhoto"><i class="fa fa-search-plus"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-12 portfolio-item html">
                    <div class="view efffect">
                        <div class="portfolio-image">
                            <img src="Templatedemo/3.jpg" alt="">
                        </div>
                        <div class="mask text-center">
                            <h3>Novel</h3>
                            <h4>Lorem ipsum dolor sit amet consectetur</h4>
                            <a href="#"><i class="fa fa-link"></i></a>
                            <a href="Templatedemo/big-item.jpg" data-gallery="prettyPhoto"><i class="fa fa-search-plus"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-12 portfolio-item wordpress">
                    <div class="view efffect">
                        <div class="portfolio-image">
                            <img src="Templatedemo/2.jpg" alt=""></div>
                        <div class="mask text-center">
                            <h3>Novel</h3>
                            <h4>Lorem ipsum dolor sit amet consectetur</h4>
                            <a href="#"><i class="fa fa-link"></i></a>
                            <a href="Templatedemo/big-item.jpg" data-gallery="prettyPhoto"><i class="fa fa-search-plus"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-12 portfolio-item joomla">
                    <div class="view efffect">
                        <div class="portfolio-image">
                            <img src="Templatedemo/1.jpg" alt=""></div>
                        <div class="mask text-center">
                            <h3>Novel</h3>
                            <h4>Lorem ipsum dolor sit amet consectetur</h4>
                            <a href="#"><i class="fa fa-link"></i></a>
                            <a href="Templatedemo/big-item.jpg" data-gallery="prettyPhoto"><i class="fa fa-search-plus"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-12 portfolio-item megento">
                    <div class="view efffect">
                        <div class="portfolio-image">
                            <img src="Templatedemo/4.jpg" alt=""></div>
                        <div class="mask text-center">
                            <h3>Novel</h3>
                            <h4>Lorem ipsum dolor sit amet consectetur</h4>
                            <a href="#"><i class="fa fa-link"></i></a>
                            <a href="Templatedemo/big-item.jpg" data-gallery="prettyPhoto"><i class="fa fa-search-plus"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section> <!--/#portfolio-->


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>